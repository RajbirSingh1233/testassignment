const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const client = require('./database');
const app = express();
const port = 3001;

app.use(bodyParser.json());
app.use(cors());

client.connect()
  .then(() => console.log("Database connected"))
  .catch(err => console.error('Database connection error:', err));

app.get('/favorites', async (req, res) => {
  console.log("Entered here");
  try {
    const query = 'SELECT * FROM universities WHERE is_favorite = true';
    const result = await client.query(query);
    console.log(result)
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching favorites:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/favorites', async (req, res) => {
  console.log("Entered")
  const { name, link, state } = req.body;
  try {
    const query = 'INSERT INTO universities (name, link, state, is_favorite) VALUES ($1, $2, $3, true)';
    await client.query(query, [name, link, state]);
    res.status(201).json({ message: 'University added to favorites successfully' });
  } catch (error) {
    console.error('Error adding university to favorites:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.delete('/favorites/:name', async (req, res) => {
  const name = req.params.name;
  console.log(name);
  try {
    const query = 'DELETE FROM universities WHERE name = $1';
    await client.query(query, [name]);
    res.status(200).json({ message: 'University removed from favorites successfully' });
  } catch (error) {
    console.error('Error removing university from favorites:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
