const {Client } = require('pg');

const client = new Client ({
    user: 'postgres',
    password: 'root1234',
    host: 'localhost',
    port: '5432',
    database: 'University'
    
})

client.on("connect", ()=> {
  console.log("Database connected");
});

client.on("end", ()=> {
  console.log("Database connection ended");
})

module.exports = client;